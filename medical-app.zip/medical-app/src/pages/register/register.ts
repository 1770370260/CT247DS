import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { RestfulserviceProvider } from '../../providers/restfulservice/restfulservice';
import { HomePage } from '../home/home';

/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {

  public userData ={"name_EN": "", "user_type": "", "email": "", "ident_no": "", "ident_type": "", "phone": "", "address": "", "username": "","password": "", "repassword": "","receive_news": "","Privacy_policy": ""};
  public data;
  public JSON_RESULT;
  public SERVER_URL = "http://localhost/metro-backend/";
  constructor(public navCtrl: NavController, public navParams: NavParams, public restfulServe:RestfulserviceProvider, public http: HttpClient) {
    RestfulserviceProvider.setHttp(this.http);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RegisterPage');
  }
  register(){
    RestfulserviceProvider.restfulPost(this.SERVER_URL+"mobileReg.php", JSON.stringify(this.userData)).subscribe(data => {
      this.JSON_RESULT = data ;
      console.log(this.JSON_RESULT[0]);
      if(this.JSON_RESULT[0].result=="帳戶已存在"){
        alert(this.JSON_RESULT[0].result);
      }else if(this.JSON_RESULT[0].result=="成功"){
        this.navCtrl.setRoot(HomePage);
      }else if(this.JSON_RESULT[0].result=="密碼不相符"){
        alert(this.JSON_RESULT[0].result);
      }else {
        console.log(this.JSON_RESULT[0].result);
      }
    
    });
    // console.log("Username: "+ this.username);

    // console.log("Password: "+ this.password);
    
  }
}
