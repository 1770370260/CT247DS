import { Component } from '@angular/core';
import { IonicPage, NavController} from 'ionic-angular';
import { HealthDemoPage } from '../health-demo/health-demo'
import { BookingPage } from '../booking/booking';

import { RestfulserviceProvider } from '../../providers/restfulservice/restfulservice';
import { HttpClient} from '@angular/common/http';
/**
 * Generated class for the HealthPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-health',
  templateUrl: 'health.html',
})
export class HealthPage {
  public DATA_URL = "http://localhost/PHP/health.php";//數據庫網址
  public JSON_RESULT;


  constructor(public navCtrl: NavController,public JsonServ: RestfulserviceProvider, public http: HttpClient) {
    RestfulserviceProvider.setHttp(this.http);
    this.appendJSON();
  }
  public appendJSON(){
    RestfulserviceProvider.restfulGet(this.DATA_URL).subscribe(data =>{
      this.JSON_RESULT = data;
    });
  }
  Demo(){
    this.navCtrl.push(BookingPage);
    
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad HealthPage');
  }

}
