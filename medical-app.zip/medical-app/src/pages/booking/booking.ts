import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { RestfulserviceProvider } from '../../providers/restfulservice/restfulservice';
import { HomePage } from '../home/home';


/**
 * Generated class for the BookingPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-booking',
  templateUrl: 'booking.html',
})
export class BookingPage {

  public userData ={"Rtime": "", "Rdate": "", "Rname": "", "Rphone": "", "Raddress": "",};
  public data;
  public JSON_RESULT;
  public SERVER_URL = "http://localhost/metro-backend/";
  
  public event = {
    month: '2019-06-14',
    timeEnds: '2019-08-14'
  }

  constructor(public navCtrl: NavController, public navParams: NavParams, public restfulServe:RestfulserviceProvider, public http: HttpClient,public alerCtrl: AlertController) {
    RestfulserviceProvider.setHttp(this.http);
  }
    doConfirm() {
      let confirm = this.alerCtrl.create({
        title: '確定提交?',
        message: '同意會提交預約到醫務所。',
        buttons: [
          {
            text: '返回',
            handler: () => {
              console.log('Disagree clicked');
            }
          },
          {
            text: '同意',
            handler: () => {
              console.log('Agree clicked');
              RestfulserviceProvider.restfulPost(this.SERVER_URL+"mbooking.php", JSON.stringify(this.userData)).subscribe(data => {
                this.JSON_RESULT = data ;
                console.log(this.JSON_RESULT[0]);
                if(this.JSON_RESULT[0].result=="預約已存在"){
                  alert(this.JSON_RESULT[0].result);
                }else if(this.JSON_RESULT[0].result=="成功"){
                  this.navCtrl.setRoot(HomePage);
                }else {
                  console.log(this.JSON_RESULT[0].result);
                }
              
              });
            }
          }
        ]
      });
      confirm.present()
  }



  ionViewDidLoad() {
    console.log('ionViewDidLoad BookingPage');
  }

}
