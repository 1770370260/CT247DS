import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestfulserviceProvider } from '../../providers/restfulservice/restfulservice';
import { HttpClient} from '@angular/common/http';
import { HomePage } from '../home/home';

/**
 * Generated class for the AccountPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-account',
  templateUrl: 'account.html',
})
export class AccountPage {

  public username;

  constructor(public navCtrl: NavController,public JsonServ: RestfulserviceProvider, public http: HttpClient) {
    RestfulserviceProvider.setHttp(this.http);
    this.appendJSON();
  }
  public appendJSON(){
    this.username=localStorage.getItem("username");
  }

  logout(){
    this.navCtrl.setRoot(HomePage);

  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AccountPage');
  }

}
