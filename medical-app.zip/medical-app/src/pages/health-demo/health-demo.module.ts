import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HealthDemoPage } from './health-demo';

@NgModule({
  declarations: [
    HealthDemoPage,
  ],
  imports: [
    IonicPageModule.forChild(HealthDemoPage),
  ],
})
export class HealthDemoPageModule {}
