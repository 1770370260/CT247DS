import { Component } from '@angular/core';
import { NavController , NavParams} from 'ionic-angular';
import { RegisterPage } from '../register/register';
import { AccountPage } from '../account/account';
import { HttpClient } from '@angular/common/http';
import { RestfulserviceProvider } from '../../providers/restfulservice/restfulservice';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  splash = true;
  public userData = {  "username": "", "password": ""};
  public data;
  public JSON_RESULT;
  public SERVER_URL = "http://localhost/metro-backend/";
  username:string;
  password:string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public restfulServe:RestfulserviceProvider, public http: HttpClient) {
    RestfulserviceProvider.setHttp(this.http);
  }

  ionViewDidLoad() {
    setTimeout(() => {
      this.splash = false;
    }, 4000);
  }

  login(){
    // console.log("Username: "+ this.username);

    // console.log("Password: "+ this.password);
    RestfulserviceProvider.restfulPost(this.SERVER_URL+"mlogin.php", JSON.stringify(this.userData)).subscribe(data => {
      this.JSON_RESULT = data ;
      console.log(this.JSON_RESULT[0]);
      if(this.JSON_RESULT[0].result=="login err"){
        alert(this.JSON_RESULT[0].result);
      }else if(this.JSON_RESULT[0].result=="succ login"){
        localStorage.setItem("username",this.JSON_RESULT[1].username);
        this.navCtrl.setRoot(AccountPage);
      }else {
        console.log(this.JSON_RESULT[0].result);
      }
    
    });
  }

  getRegister(){
    this.navCtrl.push(RegisterPage);
    
  }

 // ionViewDidLoad() {
  //   console.log('ionViewDidLoad LoginPage');
  // }

  
}