import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestfulserviceProvider } from '../../providers/restfulservice/restfulservice';
import { HttpClient} from '@angular/common/http';
/**
 * Generated class for the ServicesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-services',
  templateUrl: 'services.html',
})
export class ServicesPage {
  public DATA_URL = "http://localhost/metro-backend/clinic.php";//數據庫網址
  public JSON_RESULT;

  constructor(public navCtrl: NavController, public navParams: NavParams,public http: HttpClient) {
    RestfulserviceProvider.setHttp(this.http);
    this.appendJSON();
  }
  public appendJSON(){
    RestfulserviceProvider.restfulGet(this.DATA_URL).subscribe(data =>{
      this.JSON_RESULT = data;
    });
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ServicesPage');
  }

}
