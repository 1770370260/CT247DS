import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { RegisterPage } from '../pages/register/register';
import { AccountPage } from '../pages/account/account';
import { BookingPage } from '../pages/booking/booking';
import { ServicesPage } from '../pages/services/services';
import { HealthPage } from '../pages/health/health';
import { DoctorPage } from '../pages/doctor/doctor';
import { AboutPage } from '../pages/about/about';
import { RestfulserviceProvider } from '../providers/restfulservice/restfulservice';
import { HttpClientModule } from '@angular/common/http';


import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { SocialSharing } from '@ionic-native/social-sharing';


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    RegisterPage,
    AccountPage,
    BookingPage,
    ServicesPage,
    HealthPage,
    AboutPage,
    DoctorPage

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    RegisterPage,
    AccountPage,
    BookingPage,
    ServicesPage,
    HealthPage,
    AboutPage,
    DoctorPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    RestfulserviceProvider,
    SocialSharing,
    BarcodeScanner

  ]
})
export class AppModule {}
