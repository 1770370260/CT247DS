import { Component, ViewChild } from '@angular/core';
import { Platform, Nav } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import { BookingPage } from '../pages/booking/booking';
import { ServicesPage } from '../pages/services/services';
import { HealthPage } from '../pages/health/health';
import { AboutPage } from '../pages/about/about';
import { DoctorPage } from '../pages/doctor/doctor';
import { AccountPage } from '../pages/account/account';

import { SocialSharing } from '@ionic-native/social-sharing';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { RestfulserviceProvider } from '../providers/restfulservice/restfulservice';
import { HttpClient } from '@angular/common/http';
export interface MenuItem {
  title: string;
  component: any;
  icon: string;
}

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;
  rootPage: any = HomePage;

  appMenuItems: Array<MenuItem>;
  public userData = {"RID": "9"};

  public data;
  public JSON_RESULT;
  public SERVER_URL="http://localhost/PHP/";

  public sendTo   : any;
  public subject  : string 	= 'Message from Social Sharing App';
  public message  : string 	= 'Share your app to patient';
  public image    : string	= 'http://localhost/medical-app/img/';
  public uri      : string	= 'http://localhost/medical-app/index.html';

  constructor(
    public platform: Platform,
    private socialSharing: SocialSharing,
    public statusBar: StatusBar,
    public splashScreen: SplashScreen,
    private barcodeScanner: BarcodeScanner,
    public http: HttpClient,) {
      RestfulserviceProvider.setHttp(this.http);

    this.initializeApp();

    // used for an example of ngFor and navigation
    this.appMenuItems = [
      { title: '即時預約', component: BookingPage, icon: 'menu-pen' },
      { title: '醫療服務', component: ServicesPage, icon: 'menu-info' },
      { title: '醫務人員', component: DoctorPage, icon: 'menu-clinic' },
      { title: '健康資訊', component: HealthPage, icon: 'menu-fresh' },
      { title: '關於我們', component: AboutPage, icon: 'menu-about' }
    ];


  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
  openPage(page) {
    this.nav.setRoot(page.component);
  }
  menuAccount() {
    this.nav.setRoot(AccountPage);
  }


  startSocial(){
  
    this.platform.ready()
       .then(() =>  {
    // Check if sharing via email is supported
    this.socialSharing.canShareViaEmail().then(() => {
    // Sharing via email is possible
    // Share via email
    // shareViaEmail(message, subject, to, cc, bcc, files)
    this.socialSharing.shareViaEmail(this.message, this.subject, this.sendTo).then(() => {
    // Success!
    }).catch(() => {
    // Error!
    console.log("SHARE Social ERROR:");
    });	
   
    }).catch(() => {
    // Sharing via email is not possible
    console.log("CANNOT SHARE ERROR:");
    });
 
   });
   
 }    
 barcodeScan(){
  this.barcodeScanner.scan().then(barcodeData => {
    console.log('Barcode data', barcodeData);
    this.signup();
   }).catch(err => {
       console.log('Error', err);
   });     
 }

signup(){
  RestfulserviceProvider.restfulPost(this.SERVER_URL + "mobileSign.php", JSON.stringify(this.userData)).subscribe(data => {
      this.JSON_RESULT = data;
      console.log(this.JSON_RESULT[0]);
      if (this.JSON_RESULT[0].result == "1"){
        alert("Appointment is not confirmed."); 
      } else if (this.JSON_RESULT[0].result == "2" ) {
        alert("Already check-in. Please check your appointment.");
  } else if (this.JSON_RESULT[0].result == "3" ) {
        alert("Appointment is cancelled.");  
  } else if (this.JSON_RESULT[0].result == "4" ) {
        alert("Check-in successful.");  
      } else {
        console.log(this.JSON_RESULT[0].result);
      }

  });

}
 
 shareSocial(){
   
   this.platform.ready()
      .then(() =>  {
     this.socialSharing.share(this.message, this.subject, this.sendTo, this.uri).then(() => {
   // Success!
   }).catch(() => {
   // Error!
   console.log("SHARE Social ERROR:");
   });	
    
 
  });
  
 }
}

