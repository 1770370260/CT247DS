<?php
header("Content-type:text/html;charset=utf-8");  

 header('Access-Control-Allow-Origin: *');

 header("Access-Control-Allow-Credentials: true");
 
 header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
 header('Access-Control-Max-Age: 1000');
 
 header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "appDB";
$dbport = "3306";
$charset = "utf8";

// $dsn = "mysql:host={$dbhost};port={$dbport};dbname={$dbname};charset={$charset}";
try{
        $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=$charset",$username, $password);//dbname=數據庫名
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT CID, Cname, Cdoctor_name, Cpicture,Cphone,Cpayment,Caddress,CPtype FROM clinic_info");
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $JSONARR = array();
        foreach($stmt->fetchAll() as $row){
            $JSONOBJ = array("CID"=>$row["CID"], "Cname"=>$row["Cname"],"Cphone"=>$row["Cphone"],"Caddress"=>$row["Caddress"],"Cdoctor_name"=>$row["Cdoctor_name"],"Cpayment"=>$row["Cpayment"], "Cpicture"=>'data:'.$row["CPtype"].';base64,'.base64_encode($row["Cpicture"]));
            array_push($JSONARR,$JSONOBJ);

        }
        echo json_encode($JSONARR, JSON_UNESCAPED_UNICODE);

    }catch(PODException $e){
        echo "Error: ". $e->getMessage();
    }
    $conn = null;
    ?>