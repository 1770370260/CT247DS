<?php
    header("Access-Control-Allow-Orign");
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "appDB";  //dbname=數據庫名
    
    try{
        $mjson = file_get_contents("php://input");
        $result = json_decode($mjson);
        $conn = new PDO("mysql:host=$servername;dbname=$dbname",$username, $password);         
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT username, name_EN, password FROM user_info WHERE username = :username and password = :password LIMIT 1"); //SELECT 是主鍵
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $PSWD);

        $username = $result->username;
        $PSWD = md5($result->password); //MD5是加密
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $row = $stmt->fetchAll();

        if($stmt->rowCount() > 0){
            echo $JSON_RESULT = '[{"result": "succ login"},{"username": "'.$row[0]['username'].'", "name_EN":"'.$row[0]['name_EN'].'"}]';// 使用JSON文字檢查 

        }else{
            echo $JSON_RESULT = '[{"result": "login err"}]';
        }
    }catch(PDOException $e){
        $JSON_RESULT = '[{"result": "'. $e ->getMessage().'"}]';
        echo json_encode($JSON_RESULT, JSON_UNESCAPED_UNICODE);
    }

?>