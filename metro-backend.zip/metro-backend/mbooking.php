<?php
header("Content-type:text/html;charset=utf-8");  

header('Access-Control-Allow-Origin: *');

header("Access-Control-Allow-Credentials: true");

header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');

header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
$dbhost = "localhost";
$username = "root";
$password = "";
$dbname = "appdb";
$dbport = "3306";
$charset = "utf8";

$dsn = "mysql:host={$dbhost};port={$dbport};dbname={$dbname};charset={$charset}";
try{
    $mjson = file_get_contents("php://input");
    $result = json_decode($mjson);
    $conn = new PDO($dsn, $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("INSERT INTO reserve_data (Rtime,Rdate,Rname,Rphone,Raddress)
    VALUES (:Rtime, :Rdate, :Rname, :Rphone, :Raddress)");
    $stmt->bindParam(':Rtime', $Rtime);
    $stmt->bindParam(':Rdate', $Rdate);
    $stmt->bindParam(':Rname', $Rname);
    $stmt->bindParam(':Rphone', $Rphone);
    $stmt->bindParam(':Raddress', $Raddress);


    $Rtime= $result->Rtime;
    $Rdate= $result->Rdate ;
    $Rname= $result->Rname;
    $Raddress= $result->Raddress;
    $Rphone= $result->Rphone;


    $stmt2= $conn->prepare("SELECT RID FROM reserve_data WHERE Rname =:Rname LIMIT 1"); //SELECT主鍵
    $stmt2->bindParam(":Rname", $Rname);
    $stmt2->execute();

    if ($stmt2 -> rowCount()>0){
        echo $JSON_RESULT = '[{"result": "預約已存在"}]';
    }else{
        $stmt->execute();
        if($stmt->rowCount() >0){
            echo $JSON_RESULT = '[{"result": "成功"}]';
        }
    }
    die();
}catch(PODException $e){
    $JSON_RESULT = '[{"result": "'. $e->getmessage(). '"}]';
    echo json_encode( $JSON_RESULT, JSON_UNESCAPED_UNICODE);
}
$conn = nnull;
?>