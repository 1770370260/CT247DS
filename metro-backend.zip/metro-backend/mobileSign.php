<?php
    header("Access-Control-Allow-Origin: *");   
        $dbhost = "localhost";
        $username = "root";
        $password = "";
        $dbname = "appdb";
        $dbport = "3306";
        $charset = "utf8";

        $dsn = "mysql:host={$dbhost};port={$dbport};dbname={$dbname};charset={$charset}";

		//$d=date("Y-m-d h:i:sa");
        //  $CurDate=date("Y-m-d");
        $CurDate=date("Y-m-d h:i:sa");  
	 
        try {
            $mjson = file_get_contents("php://input"); 
            $result = json_decode($mjson); 
		    //$RID = $result -> RID; 
            // $RID =$_GET["RID"]; 


            $conn = new PDO($dsn, $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $stmt = $conn->prepare("UPDATE reserve_data SET Rcondition = '2', Rregisttime = :CurDate WHERE RID= :RID"); 
            $stmt-> bindParam(":RID", $RID);
            $stmt-> bindParam(":CurDate", $CurDate);
            
			$RID = $result -> RID; 
              
            $stmt2 = $conn->prepare("Select Rcondition from reserve_data where RID= :RID");
            $stmt2-> bindParam(":RID", $RID);
            $stmt2->execute();
            $result = $stmt2->fetch(PDO::FETCH_OBJ);

            //echo $JSON_RESULT =$result->Rcondition;
                
            
				if ($stmt2->rowCount() <= 0 ) {
                  
                    echo $JSON_RESULT = '[{"result": "Appointment record not found."}]' ;  
                    exit(0);
                  
                } else { 
				
               				 
				 switch ($result->Rcondition) {
                 case "1":
                    echo $JSON_RESULT = '[{"result": "1"}]' ;
                    exit(0);
                 case "2":
                   echo $JSON_RESULT = '[{"result": "2"}]' ;   
                   exit(0);
                 case "3":
                   echo $JSON_RESULT = '[{"result": "1"}]' ;
                   exit(0);
				 case "4":
                   echo $JSON_RESULT = '[{"result": "4"}]' ; 
				   $stmt->execute();
                   exit(0);
				 case "5":
                   echo $JSON_RESULT = '[{"result": "3"}]' ; 
                   exit(0);  
                 default:
                    echo $JSON_RESULT = '[{"result": "1"}]' ;
                }
				 
				 
				 
			    }  				

            
          die();
        } catch(PDOException $e){
          $JSON_RESULT = '[{"result": "'. $e->getMessage().'"}]'; 
          echo json_encode( $JSON_RESULT, JSON_UNESCAPED_UNICODE);
        }

        $conn = null;

?>