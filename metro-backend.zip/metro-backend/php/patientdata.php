<!DOCTYPE html>
<html>
<head>
<?php include '../php/index.php';?>
</head>
<body>
<div id="page-wrapper">
<h1 class="page-header">病人資料庫</h1>
    <div>
        <button  class="dark-btn align-r" onclick="location.href='p_add.php?UID=$UID'" >新增資料</button>
    </div>
    <div>
        <table>
        <tr class="secondary">
        <th>病患名稱</th>
                <th>病患電話</th>
                <th>病患地址</th>
                <th>患病類型</th>
                <th>電郵</th>
                <th></th>
            </tr>
            <?php
            $conn = new mysqli('localhost', 'root', '','appDB');
            mysqli_set_charset($conn,"utf8");

            $sql ="select * from patient_data ";
            $result=$conn->query($sql);
            while($row = $result->fetch_assoc()){
            ?>
            <tr>
                <td  class="td-s">
                    <?php echo $row['Pname'] ?>
                </td>
                <td>
                    <?php echo $row['Pphone'] ?>
                </td>
                <td class="td-l">
                    <?php echo $row['Paddress'] ?>
                </td>
                <td>
                    <?php echo $row['Ptype'] ?>
                </td>

                <td>
                    <?php echo $row['Pemail'] ?>
                </td>
                <td>
                <input class="clear-btn danger" type="button" onclick="window.location.href='patientdata_delete.php?PID=<?PHP echo $row['PID']; ?>'" value="删除"/>
                <input class="clear-btn secondary" type="button" onclick="window.location.href='p_update.php?PID=<?PHP echo $row['PID']; ?>'" value="编輯"/>
                </td>
            </tr>
            <?php 
            }
            ?>
            </table>   
    </div>
</div>    </div>
</body>
</html>