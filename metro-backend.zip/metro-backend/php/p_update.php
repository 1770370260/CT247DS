<!DOCTYPE html>
<html>
<head>
<?php include '../php/index.php';?>

</head>
<body>
<div id="page-wrapper">
<h1 class="page-header">病人個人資料表</h1>

        <table >
            <tr>
                <th></th>
                <th>病患名稱</th>
                <th>病患電話</th>
                <th>病患地址</th>
                <th>患病類型</th>
                <th>電郵</th>
            </tr>
            <?php
            $PID = $_GET['PID'];
            $conn = new mysqli('localhost', 'root', '','appDB');
            mysqli_set_charset($conn,"utf8");

            $sql ="select * from patient_data where PID = $PID";
            $result=$conn->query($sql);
            while($row = $result->fetch_assoc()){
            ?>
            <tr>
            <form action="patientdata_update.php" method="post">
                <td>
                <input type="hidden" name="PID" value="<?php 
                echo $row["PID"] ?>">
                <td>
                <input type="Text" name="Pname" value="<?php 
                echo $row["Pname"] ?>">
                </td>
                <td>
                <input type="Text" name="Pphone" value="<?php 
                echo $row["Pphone"] ?>">
                </td>
                <td>
                <input type="Text" name="Paddress" value="<?php 
                echo $row["Paddress"] ?>">
                </td>
                <td>
                <input type="Text" name="Ptype" value="<?php 
                echo $row["Ptype"] ?>">
                </td>
                <td>
                <input type="Text" name="Pemail" value="<?php 
                echo $row["Pemail"] ?>">
                <td>
            </tr>
            <?php 
            }
            ?>
            </table>   
    <br>
    <div class="align-r">
    <button class="primary-btn" type="submit">提交</button>
    <button class="clear-btn cancel" type="button" onclick="window.location.href='patientdata.php'">取消</button>
        </div>
    </form>
</div>
</body>
</html>