<?php
    header("charset=utf-8");
         $charset = "utf8";
        $title = $_POST['Htitle'];
        $intro = $_POST['Hintro'];
        $create_datetime = $_POST['Hcreate_datetime'];
        $payment = $_POST['Hpayment'];
        $size = $_FILES['Hpicture']['size'];
        $name = $_FILES['Hpicture']['name'];
        $tmp_name = $_FILES['Hpicture']['tmp_name'];
        $type = $_FILES['Hpicture']['type'];
        $release_status = $_POST['Hrelease_status'];
        $HID= $_GET['HID'];
        $data = addslashes(fread(fopen($tmp_name, "r"), filesize($tmp_name)));
        $conn = new mysqli('localhost', 'root', '','appDB');
        mysqli_set_charset($conn,"utf8");

        if ($conn->connect_error){
            echo '數據庫連接失敗！';
            exit(0);
        }else{
            if ($title == ''){
                echo '<script>alert("標題不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($payment == ''){
                echo '<script>alert("價格不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($release_status == ''){
                echo '<script>alert("發佈狀態不能為空！");history.go(-1);</script>';
                exit(0);}
        
            $sql = "select Htitle and Hcreate_datetime from health_info where Htitle = '$_POST[Htitle]' and Hcreate_datetime = '$_POST[Hcreate_datetime]' ";
            $result = $conn->query($sql);
            $number = mysqli_num_rows($result);
            if ($number) {
                echo '<script>alert("信息不可重複");history.go(-1);</script>';
            } else {
                $sql_insert = "insert into health_info 
                values('','$_POST[Htitle]','$_POST[Hintro]','$_POST[Hcreate_datetime]','$_POST[Hrelease_status]','$data','$type','$_POST[Hpayment]')";
                $res_insert = $conn->query($sql_insert);
        if ($res_insert) {
            echo "<script>alert('新增成功！')</script>";echo '<script>window.location.href="health.php";</script>';
        }else {
            echo "<script>alert('新增失敗！'); history.go(-1);</script>";
        }}}
?>