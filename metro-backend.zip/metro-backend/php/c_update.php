<!DOCTYPE html>
<html>
<head>
<?php include '../php/index.php';?>

</head>
<body>

<div id="page-wrapper">
<h1 class="page-header">醫務所資訊</h1>


        <table >
            <tr>
                <th></th>
                <th>醫務所名稱</th>
                <th>醫生</th>
                <th>主理醫療項目</th>
                <th>醫務所地址</th>
                <th>图片</th>
                <th>電話</th>
                <th>發佈狀態</th>
                <th>收費</th>
            </tr>
            <?php
            $CID = $_GET['CID'];
            $conn = new mysqli('localhost', 'root', '','appDB');
            mysqli_set_charset($conn,"utf8");

            $sql ="select * from clinic_info where CID = $CID";
            $result=$conn->query($sql);
            while($row = $result->fetch_assoc()){
            ?>
            <tr>
            <form action="clinic_update.php" method="post" enctype="multipart/form-data">
                <td>
                <input type="hidden" name="CID" value="<?php 
                echo $row["CID"] ?>" style="width:80px">
                <td>
                <input type="Text" name="Cname" value="<?php 
                echo $row["Cname"] ?>" style="width:80px">
                </td>
                <td>
                <input type="Text" name="Cdoctor_name" value="<?php 
                echo $row["Cdoctor_name"] ?>" style="width:80px">
                </td>
                <td>
                <input type="Text" name="Cpractice_type" value="<?php 
                echo $row["Cpractice_type"] ?>" style="width:100px">
                </td>
                <td>
                <input type="Text" name="Caddress" value="<?php 
                echo $row["Caddress"] ?>" style="width:80px">
                </td>
                <td>
                <input type="file" name="Cpicture" style="width:150px">
                </td>
                <td>
                <input type="Text" name="Cphone" value="<?php 
                echo $row["Cphone"] ?>" style="width:80px">
                </td>
                <td>
                <?php
                $a=$row['Crelease_status'];
                $b="<input type='radio' name='Crelease_status' value='1' checked>發佈中
                <input type='radio' name='Crelease_status' value='2'>發佈結束
                <input type='radio' name='Crelease_status' value='3'>未發佈";
                $c="<input type='radio' name='Crelease_status' value='1'>發佈中
                <input type='radio' name='Crelease_status' value='2' checked>發佈結束
                <input type='radio' name='Crelease_status' value='3'>未發佈";
                $d="<input type='radio' name='Crelease_status' value='1'>發佈中
                <input type='radio' name='Crelease_status' value='2'>發佈結束
                <input type='radio' name='Crelease_status' value='3' checked>未發佈";
                if($a=="1"){echo $b;}
                if($a=="2"){echo $c;}
                if($a=="3"){echo $d;}
                ?>
                </td>
                <td>
                <input type="Text" name="Cpayment" value="<?php 
                echo $row["Cpayment"] ?>" style="width:80px">
                </td>
            </tr>
            <?php 
            }
            ?>
            </table>   
    
    <br>
    <div class="align-r">
    <button class="primary-btn" type="submit">提交</button>
    <button class="clear-btn cancel" type="button" onclick="window.location.href='clinic.php'">取消</button>
        </div>
        </form>
</div>
</body>
</html>