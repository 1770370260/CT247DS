<!DOCTYPE html>
<html>
<head>

<?php include '../php/index.php';?>
</head>
<body>


<div id="page-wrapper">
    
    <h1 class="page-header">儀表版</h1>
    <script>
    document.cookie = "Cres_select"+" = "+""+";" ;
    document.cookie = "Hres_select"+" = "+""+";" ;
    document.cookie = "Rres_select"+" = "+""+";" ;
    </script>
    

    <div class="card">
    <div class="row">
    <div class="col-md-9">
        <?php 
        echo "歡迎回來 " . "<span class='primary'> $username </span>" . ",<br>" ;
        echo "您有 " . "<span style='color:#ffcb66;font-size:18px;'> $num </span>" . "個新預約尚未處理。<br>";
        echo "您有 " . "<span style='color:#ffcb66;font-size:18px;'> $num2 </span>" . "個預約已签到。<br>";
        echo "您有 " . "<span style='color:#ffcb66;font-size:18px;'> $num3 </span>" . "個預約進行中。<br>";
        echo "您有 " . "<span style='color:#ffcb66;font-size:18px;'> $num5 </span>" . "個預約已取消。<br>";
        echo "您有 " . "<span style='color:#ffcb66;font-size:18px;'> $num4 </span>" . "個預約已完成。";
?> 
        </div>
    <div class="col-md-2">
    <p> </p><br><p></p>
        <button class="primary-btn" onclick="window.location.href='reservedata.php'">查看預約</button>
</div>   
 </div>
 </div>
</body>
</html>