<!DOCTYPE html>
<html>
<head>
<?php include '../php/index.php';?>

</head>
<body>


<div id="page-wrapper">
<h1 class="page-header">編輯病人預約記錄表</h1>


    <div>
        <table>
            <tr>
                <th></th>
                <th>姓名</th>
                <th>電話</th>
                <th>預約地址</th>
                <th>處理狀態</th>
                <th>預約日期</th>
                <th>預約時間</th>
            </tr>
            <?php 
            
            $RID = $_GET['RID'];
            $conn = new mysqli('localhost', 'root', '','appDB');
            mysqli_set_charset($conn,"utf8");

            $sql ="select * from reserve_data where RID = $RID";
            $result=$conn->query($sql);
            while($row = $result->fetch_assoc()){
            ?>
            <tr>
            <form action="reservedata_update.php" method="post">
                <td>
                <input type="hidden" name="RID" value="<?php 
                echo $row["RID"] ?>">
                </td>
                <td>
                <input type="Text" name="Rname" value="<?php 
                echo $row["Rname"] ?>">
                </td>
                <td>
                <input type="Text" name="Rphone" value="<?php 
                echo $row["Rphone"] ?>">
                </td>
                <td>
                <input type="Text" name="Raddress" value="<?php 
                echo $row["Raddress"] ?>">
                <datalist id="addresslist">
                <option >荃灣都會醫務所</option>
        <option >金鐘都會醫務所</option>
        <option >旺角都會醫務所</option>
                </datalist>
                </td>
                <td>
                <?php
                $a=$row["Rcondition"];
                $b="<input type='radio' name='Rcondition' value='1' checked>新預約
                <input type='radio' name='Rcondition' value='2'>已簽到
                <input type='radio' name='Rcondition' value='3'>預約中<br>
                <input type='radio' name='Rcondition' value='4'>已完成預約
                <input type='radio' name='Rcondition' value='5'>取消預約";
                $c="<input type='radio' name='Rcondition' value='1'>新預約
                <input type='radio' name='Rcondition' value='2' checked>已簽到
                <input type='radio' name='Rcondition' value='3'>預約中<br>
                <input type='radio' name='Rcondition' value='4'>已完成預約
                <input type='radio' name='Rcondition' value='5'>取消預約";
                $d="<input type='radio' name='Rcondition' value='1'>新預約
                <input type='radio' name='Rcondition' value='2'>已簽到
                <input type='radio' name='Rcondition' value='3' checked>預約中<br>
                <input type='radio' name='Rcondition' value='4'>已完成預約
                <input type='radio' name='Rcondition' value='5'>取消預約";
                $e="<input type='radio' name='Rcondition' value='1'>新預約
                <input type='radio' name='Rcondition' value='2'>已簽到
                <input type='radio' name='Rcondition' value='3'>預約中<br>
                <input type='radio' name='Rcondition' value='4' checked>已完成預約
                <input type='radio' name='Rcondition' value='5'>取消預約";
                $f="<input type='radio' name='Rcondition' value='1'>新預約
                <input type='radio' name='Rcondition' value='2'>已簽到
                <input type='radio' name='Rcondition' value='3'>預約中<br>
                <input type='radio' name='Rcondition' value='4'>已完成預約
                <input type='radio' name='Rcondition' value='5' checked>取消預約";
                if($a=="1"){echo $b;}
                if($a=="2"){echo $c;}
                if($a=="3"){echo $d;}
                if($a=="4"){echo $e;}
                if($a=="5"){echo $f;}
                ?>
                </td>
                <td>
                <input type="date" name="Rdate" value="<?php 
                echo $row["Rdate"] ?>">
                </td>
                <td>
                <?php
                $g=$row["Rtime"];
                $h="<input type='radio' name='Rtime' value='1' checked>08:00-10:00
                <input type='radio' name='Rtime' value='2'>10:00-15:00<br>
                <input type='radio' name='Rtime' value='3'>14:00-16:00
                <input type='radio' name='Rtime' value='4'>16:00-18:00";
                $i="<input type='radio' name='Rtime' value='1'>08:00-10:00
                <input type='radio' name='Rtime' value='2' checked>10:00-15:00<br>
                <input type='radio' name='Rtime' value='3'>14:00-16:00
                <input type='radio' name='Rtime' value='4'>16:00-18:00";
                $j="<input type='radio' name='Rtime' value='1'>08:00-10:00
                <input type='radio' name='Rtime' value='2'>10:00-15:00<br>
                <input type='radio' name='Rtime' value='3' checked>14:00-16:00
                <input type='radio' name='Rtime' value='4'>16:00-18:00";
                $k="<input type='radio' name='Rtime' value='1'>08:00-10:00
                <input type='radio' name='Rtime' value='2'>10:00-15:00<br>
                <input type='radio' name='Rtime' value='3'>14:00-16:00
                <input type='radio' name='Rtime' value='4' checked>16:00-18:00";
                if($g=="1"){echo $h;}
                if($g=="2"){echo $i;}
                if($g=="3"){echo $j;}
                if($g=="4"){echo $k;}
                ?>
                </td>
            </tr>
            <?php 
            }    
            ?>
            </table>   
    </div><br>
    <div class="align-r">
    <button class="clear-btn cancel" type="button" onclick="window.location.href='reservedata.php'">取消</button>
    <button class="primary-btn" type="submit">提交</button>
        </div>
        </form>
</div>
</body>
</html>