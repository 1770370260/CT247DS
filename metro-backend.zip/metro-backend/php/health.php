<!DOCTYPE html>
<html>
<head>
<?php include '../php/index.php';?>
</head>
<body>

<div id="page-wrapper">
<h1 class="page-header">醫療健康資訊</h1>

    <div>
        過濾選項：
        <select id="Hslt" onchange="test()">
        <option value="">請選擇</option>
        <option value="1">發佈中</option>
        <option value="2">發佈結束</option>
        <option value="3">未發佈</option>
        <option value="">所有</option>
        </select>
        <script>
        document.cookie = "Hres_select"+" = "+""+";" ;
        function test(){
        var name = "Hres_select",value=document.getElementById("Hslt").value;
        document.cookie = name+" = "+value+";" ;
        window.location.reload();
        }
        </script>
        <button  class="align-r dark-btn" style="margin-left:10px;" onclick="location.href='h_add.php?UID=$UID'" >新增資料</button>
    </div>
    <div>
        <table style="border: soild 1px black">
            <tr>
            <th>標題</th>
                <th>簡介</th>
                <th>發佈日期</th>
                <th>發佈狀態</th>
                <th>圖片</th>
                <th>收費</th>
                <th></th>
            </tr>
            <?php
            $conn = new mysqli('localhost', 'root', '','appDB');
            mysqli_set_charset($conn,"utf8");

            $res_select=$_COOKIE["Hres_select"];
            switch ($res_select) {
                case "1":
                $sql="select * from health_info where Hrelease_status = '1'";
                  break;
                case "2":
                $sql="select * from health_info where Hrelease_status = '2'";
                  break;
                case "3":
                $sql="select * from health_info where Hrelease_status = '3'";
                  break;
                default:
                $sql="select * from health_info";
            }           
             $result=$conn->query($sql);
            while($row = $result->fetch_assoc()){
            ?>
            <tr>
                <td>
                    <?php echo $row['Htitle'] ?>
                </td>
                <td class="td-l">
                    <?php echo $row['Hintro'] ?>
                </td>
                <td>
                    <?php echo $row['Hcreate_datetime'] ?>
                </td>
                <td>
                <?php 
                    $a = $row['Hrelease_status'];
                    if ($a == "1"){echo "發佈中";}
                    if ($a == "2"){echo "發佈結束";}
                    if ($a == "3"){echo "未發佈";}
                    ?>
                </td>
                <td>           
                <?PHP 
                echo '<img src="data:'.$row["HPtype"].";base64,".
                base64_encode($row["Hpicture"]).'">'; 
                ?>
                </td>
                <td>
                    <?php echo $row['Hpayment'] ?>
                </td>
                <td>
                <input class="clear-btn danger" type="button" onclick="window.location.href='health_delete.php?HID=<?PHP echo $row['HID']; ?>'" value="删除"/>
                <input class="clear-btn secondary" type="button" onclick="window.location.href='h_update.php?HID=<?PHP echo $row['HID']; ?>'" value="编辑"/>
                </td>
            </tr>
            <?php 
            }
            ?>
            </table>  
            
            <form action="../r_push.php" method="post">
    
                <button type="submit">發送推送通知</button>

    </div></div>
</div>
</body>
</html>