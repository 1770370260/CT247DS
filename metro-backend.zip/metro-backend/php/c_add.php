<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <?php include '../php/index.php';?>
</head>

<body>


<div id="page-wrapper">
    
        <h1 class="page-header">新增醫務所資料</h1>
        <form action="clinic_add.php" method="post">
    <div>
    <label>醫務所名稱</label>
        <input type="text" name="Cname">
        <label>醫生</label>
        <input type="text" name="Cdoctor_name">
        <label>主理醫療項目</label>
        <input type="text" name="Cpractice_type">
        <label>醫務所地址</label>
        <input type="text" name="Caddress">
        <label>圖片</label>
        <input type="file" name="Cpicture">
        <label>電話</label>
		<input type="text" name="Cphone">
		<label>發佈狀態</label>
        <input type="radio" name="Crelease_status" value="1">發佈中
        <input type="radio" name="Crelease_status" value="2">發佈結束
        <input type="radio" name="Crelease_status" value="3">未發佈
        <label>收費</label>
        <input type="text" name="Cpayment">
        <br><br>
    </div>

    <div class="align-r">
    <button class="clear-btn cancel" type="button" class="clear-btn cancel" onclick="window.location.href='clinic.php?UID=<?PHP echo $_SESSION['UID'] ?>' ">取消</button>
    <button class="primary-btn" type="submit" class="primary-btn" onclick="window.location.href='clinic.php?UID=<?PHP echo $_SESSION['UID'] ?>' ">提交</button>
</div>
    </form>
</div>

</body>
</html>

