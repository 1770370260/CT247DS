<?php
header("Content-type: text/html; charset=utf-8");
    $Cname = $_POST['Cname'];
    $doctor_name = $_POST['Cdoctor_name'];
    $practice_type = $_POST['Cpractice_type'];
    $Caddress = $_POST['Caddress'];
    $size = $_FILES['Cpicture']['size'];
    $name = $_FILES['Cpicture']['name'];
    $tmp_name = $_FILES['Cpicture']['tmp_name'];
    $type = $_FILES['Cpicture']['type'];
    $Cphone = $_POST['Cphone'];
    $Cpayment = $_POST['Cpayment'];
    $release_status = $_POST['Crelease_status'];
    $CID = $_POST['CID'];

    $conn = new mysqli('localhost','root','','appDB');
    mysqli_set_charset($conn,"utf8");

    if ($conn->connect_error){
        echo '數據庫連接失敗！';exit(0);
    }else {
        if($tmp_name!=""){
        $data = addslashes(fread(fopen($tmp_name, "r"), filesize($tmp_name)));
        $sql_update = "update clinic_info set Cname='$Cname',Cdoctor_name='$doctor_name',Cpractice_type='$practice_type',
        Caddress='$Caddress',Cpicture='$data',CPtype='$type',Cphone='$Cphone',Crelease_status='$release_status',Cpayment='$Cpayment'
        where CID = '$CID'";}
        else{
        $sql_update = "update clinic_info set Cname='$Cname',Cdoctor_name='$doctor_name',Cpractice_type='$practice_type',
        Caddress='$Caddress',Cphone='$Cphone',Crelease_status='$release_status',Cpayment='$Cpayment'
        where CID = '$CID'";}
        $res_update = $conn->query($sql_update);
    if ($res_update) {
        echo "<script>alert('更新成功！')</script>";echo '<script>window.location.href="clinic.php";</script>';
    }else {
        echo "<script>alert('更新失敗！'); history.go(-1);</script>";
    }}
?>