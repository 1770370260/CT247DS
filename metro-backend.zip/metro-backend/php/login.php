<?php session_start();
    header("Content-type: text/html; charset=utf-8");
    $username = $_POST['username'];
    $password = $_POST['password'];
    $conn = new mysqli('localhost', 'root', '','appDB');//连接到数据库
    
    $sqlid = "select UID from user_info where username = '$username'";
    $resid = $conn->query($sqlid);
    $row = $resid->fetch_assoc();
    $UID = $row['UID'];
    $_SESSION["UID"]=$UID;
    if ($conn->connect_error){
        echo '數據庫連接失敗！';
        exit(0);
    }else{
        if ($username == ''){
            echo '<script>alert("請輸入用戶名！");history.go(-1);</script>';
            exit(0);
        }
        if ($password == ''){
            echo '<script>alert("請輸入密碼！");history.go(-1);</script>';
            exit(0);
        }
        $sql = "select username and password from user_info where 
        username = '$username' and password = '$password'";//构建查询语句
        $result = $conn->query($sql);//执行查询
        $number = mysqli_num_rows($result);
        if ($number) {
            echo "<script>"; 
            echo "window.location.href='home.php?UID=".$UID."'";  
            echo "</script>";
        } else {
            echo '<script>alert("賬戶或密碼錯誤！");history.go(-1);</script>';
        }
    }
?>