<?php
    header("Content-type: text/html; charset=utf-8");
    $username = $_POST['username'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $phone = $_POST['phone'];
    $user_type = $_POST['user_type'];
    $name_CN = $_POST['name_CN'];
    $name_EN = $_POST['name_EN'];
    $email = $_POST['email'];
    $address_CN = $_POST['address_CN'];
    $ident_type = $_POST['ident_type'];
    $ident_no = $_POST['ident_no'];
    $confirm_reg = $_POST['confirm_reg'];
    $notification = $_POST['notification'];
    
    $conn = new mysqli('localhost', 'root', '','appDB');//连接到数据库
    mysqli_set_charset($conn,"utf8");

    $pattern="/([a-z0-9]*[-_.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[.][a-z]{2,3}([.][a-z]{2})?/i";

    if ($conn->connect_error){
        echo '數據庫連接失敗！';
        exit(0);
    }else{
        if ($username == ''){
            echo '<script>alert("請輸入用戶名！");history.go(-1);</script>';
            exit(0);}
        if ($password == ''){
            echo '<script>alert("請輸入密碼！");history.go(-1);</script>';
            exit(0);}
        if ($password != $repassword){
            echo '<script>alert("兩次密碼不一致！");history.go(-1);</script>';
            exit(0);}
        if ($repassword == ''){
            echo '<script>alert("請確認密碼！");history.go(-1);</script>';
            exit(0);}
        if ($user_type == ''){
            echo '<script>alert("請選擇稱謂！");history.go(-1);</script>';
            exit(0);}
        if ($name_CN == ''){
            echo '<script>alert("請輸入中文名！");history.go(-1);</script>';
            exit(0);}
        if ($name_EN == ''){
            echo '<script>alert("請輸入英文名！");history.go(-1);</script>';
            exit(0);}
        if ($ident_type == ''){
            echo '<script>alert("請選擇證件類型！");history.go(-1);</script>';
            exit(0);}
        if ($ident_no == ''){
            echo '<script>alert("請輸入證件號碼！");history.go(-1);</script>';
            exit(0);}
        if ($email == ''){
            echo '<script>alert("請輸入電子郵件！");history.go(-1);</script>';
            exit(0);}

        if(preg_match($pattern,$email)){
        if($password == $repassword){ 
            $sql = "select username from user_info where username = '$_POST[username]'";
            $result = $conn->query($sql);
            $number = mysqli_num_rows($result);
            if ($number) {
                echo '<script>alert("用戶名已經存在");history.go(-1);</script>';
            } else {
                $sql_insert = "insert into user_info (username,password,phone,user_type,repassword,name_CN,name_EN,email,address_CN,ident_type,ident_no,confirm_reg,notification) 
                values('$_POST[username]','$_POST[password]','$_POST[phone]','$_POST[user_type]','$_POST[repassword]','$_POST[name_CN]','$_POST[name_EN]','$_POST[email]','$_POST[address_CN]','$_POST[ident_type]','$_POST[ident_no]','$_POST[confirm_reg]','$_POST[notification]')";
                $res_insert = $conn->query($sql_insert);
                if ($res_insert) {
                    echo '<script>window.location.href="login.html";</script>';
                } else {
                    echo "<script>alert('系統繁忙，請稍後！');</script>";
                }}}else{
                echo "<script>alert('註冊失敗！'); history.go(-1);</script>";
                }}else{
                echo "<script>alert('郵箱格式錯誤！'); history.go(-1);</script>";
                }}
?>