<?php
header("Content-type: text/html; charset=utf-8");
    $title = $_POST['Htitle'];
    $intro = $_POST['Hintro'];
    $create_datetime = $_POST['Hcreate_datetime'];
    $payment = $_POST['Hpayment'];
    $size = $_FILES['Hpicture']['size'];
    $name = $_FILES['Hpicture']['name'];
    $tmp_name = $_FILES['Hpicture']['tmp_name'];
    $type = $_FILES['Hpicture']['type'];
    $release_status = $_POST['Hrelease_status'];
    $HID = $_POST['HID'];
    $conn = new mysqli('localhost','root','','appDB');
        mysqli_set_charset($conn,"utf8");

        if ($conn->connect_error){
            echo '數據庫連接失敗！';exit(0);
        }else {
            if($tmp_name!=""){
            $data = addslashes(fread(fopen($tmp_name, "r"), filesize($tmp_name)));
            $sql_update = "update health_info set Htitle='$title',Hintro='$intro',Hcreate_datetime='$create_datetime',
            Hpayment='$payment',Hrelease_status='$release_status',Hpicture='$data',HPtype='$type'
            where HID = '$HID'";}
            else{
            $sql_update = "update health_info set Htitle='$title',Hintro='$intro',Hcreate_datetime='$create_datetime',
            Hpayment='$payment',Hrelease_status='$release_status'
            where HID = '$HID'";}
            $res_update = $conn->query($sql_update);
            if ($res_update) {
                echo "<script>alert('更新成功！')</script>";echo '<script>window.location.href="health.php";</script>';
            }else {
                echo "<script>alert('更新失敗！'); history.go(-1);</script>";
        }}
?>