<?php
header("Content-type: text/html; charset=utf-8");
    $Pname = $_POST['Pname'];
    $Pphone = $_POST['Pphone'];
    $Paddress = $_POST['Paddress'];
    $Ptype = $_POST['Ptype'];
    $Pemail = $_POST['Pemail'];
    $PID = $_POST['PID'];

    $conn = new mysqli('localhost','root','','appDB');
    mysqli_set_charset($conn,"utf8");

        if ($conn->connect_error){
            echo '數據庫連接失敗！';exit(0);
        }else {
            $pattern="/([a-z0-9]*[-_.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[.][a-z]{2,3}([.][a-z]{2})?/i";
            if(preg_match($pattern,$Pemail)){
            $sql_update = "update patient_data set Pemail='$Pemail',
            Pname='$Pname',Paddress='$Paddress',Pphone='$Pphone',Ptype='$Ptype'
            where PID = '$PID'";
            $res_update = $conn->query($sql_update);
        if ($res_update) {
            echo "<script>alert('更新成功！')</script>";echo '<script>window.location.href="patientdata.php";</script>';
        }else {
            echo "<script>alert('更新失敗！'); history.go(-1);</script>";
        }}else{echo "<script>alert('郵箱格式錯誤！'); history.go(-1);</script>";}}
?>