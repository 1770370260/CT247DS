<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <?php include '../php/index.php';?>
</head>

<body>


<div id="page-wrapper">
    
        <h1 class="page-header">新增病人資料庫</h1>
        <form action="../php/patientdata_add.php" method="post">
    <div>
        <label>病患名稱</label>
        <input type="text" name="Pname"><br>
        <label>病患電話</label>
        <input type="text" name="Pphone"><br>
        <label>病患地址</label>
        <input type="text" name="Paddress"><br>
        <label>患病類型</label>
        <input type="text" name="Ptype"><br>
        <label>電郵</label>
        <input type="text" name="Pemail">
    </div>
    <br>
    <div class="align-r">

    <button class="clear-btn cancel" type="button" onclick="window.location.href='patientdata.php?UID=<?PHP echo $_SESSION['UID'] ?>' ">取消</button>
    <button class="primary-btn" type="submit">提交</button>
</div>

   </form>
</div>

</body>
</html>