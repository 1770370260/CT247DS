
<?php
header("Content-type: text/html; charset=utf-8");
    $time = $_POST['Rtime'];
    $date = $_POST['Rdate'];
    $Rname = $_POST['Rname'];
    $Raddress = $_POST['Raddress'];
    $Rphone = $_POST['Rphone'];
    $Rcondition = $_POST['Rcondition'];
    $RID = $_POST['RID'];

    $conn = new mysqli('localhost','root','','appDB');
    mysqli_set_charset($conn,"utf8");

        if ($conn->connect_error){
            echo '數據庫連接失敗！';exit(0);
        }else {
            $sql_update = "update reserve_data set Rtime='$time',Rdate='$date',
            Rname='$Rname',Raddress='$Raddress',Rphone='$Rphone',Rcondition='$Rcondition'
            where RID = '$RID'";
            $res_update = $conn->query($sql_update);
        if ($res_update) {
            echo "<script>alert('更新成功！')</script>";echo '<script>window.location.href="reservedata.php";</script>';
        }else {
            echo "<script>alert('更新失敗！'); history.go(-1);</script>";
        }}
?>