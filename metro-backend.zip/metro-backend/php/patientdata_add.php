<?php
    header("Content-type: text/html; charset=utf-8");
    $Pname = $_POST['Pname'];
    $Pphone = $_POST['Pphone'];
    $Paddress = $_POST['Paddress'];
    $Ptype = $_POST['Ptype'];
    $Pemail = $_POST['Pemail'];
    $PID = $_GET['PID'];
    $conn = new mysqli('localhost', 'root', '','appDB');
    mysqli_set_charset($conn,"utf8");


        if ($conn->connect_error){
            echo '數據庫連接失敗！';
            exit(0);
        }else{
            if ($Pname == ''){
                echo '<script>alert("病人名不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($Pphone == ''){
                echo '<script>alert("電話不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($Paddress == ''){
                echo '<script>alert("地址不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($Ptype == ''){
                echo '<script>alert("患病類型不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($Pemail == ''){
                echo '<script>alert("電郵不能為空！");history.go(-1);</script>';
                exit(0);}

            $pattern="/([a-z0-9]*[-_.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[.][a-z]{2,3}([.][a-z]{2})?/i";
            if(preg_match($pattern,$Pemail)){
            $sql = "select Pname and Paddress from patient_data where Pname = '$_POST[Pname]' and Paddress = '$_POST[Paddress]'";
            $result = $conn->query($sql);
            $number = mysqli_num_rows($result);
            if ($number) {
                echo '<script>alert("信息不可重複");history.go(-1);</script>';
            } else {
                $sql_insert = "insert into patient_data 
                values('','$_POST[Pname]','$_POST[Pphone]','$_POST[Paddress]','$_POST[Ptype]','$_POST[Pemail]')";
                $res_insert = $conn->query($sql_insert);
        if ($res_insert) {
            echo "<script>alert('新增成功！')</script>";echo '<script>window.location.href="patientdata.php";</script>';
        }else {
            echo "<script>alert('新增失敗！'); history.go(-1);</script>";
        }}}else{echo "<script>alert('郵箱格式錯誤！'); history.go(-1);</script>";
        }}
?>