<!DOCTYPE html>
<html>
<head>
<?php include '../php/index.php';?>
</head>
<body>
<div>
<div id="page-wrapper">
<h1 class="page-header">編輯健康資訊</h1>
<div>
        <table>
            <tr>
                <th></th>
                <th>標題</th>
                <th>簡介</th>
                <th>發佈日期</th>
                <th>發佈狀態</th>
                <th>圖片</th>
                <th>收費</th>
            </tr>
            <?php
            $HID = $_GET['HID'];
            $conn = new mysqli('localhost', 'root', '','appDB');
            mysqli_set_charset($conn,"utf8");

            $sql ="select * from health_info where HID = $HID";
            $result=$conn->query($sql);
            while($row = $result->fetch_assoc()){
            ?>
            <tr>
            <form action="health_update.php" method="post" enctype="multipart/form-data">
                <td>
                <input type="hidden" name="HID" value="<?php 
                echo $row["HID"] ?>">
                <td>
                <input type="Text" name="Htitle" value="<?php 
                echo $row["Htitle"] ?>">
                </td>
                <td>
                <input type="Text" name="Hintro" value="<?php 
                echo $row["Hintro"] ?>">
                </td>
                <td>
                <input type="date" name="Hcreate_datetime" value="<?php 
                echo $row["Hcreate_datetime"] ?>">
                </td>
                <td>
                <?php
                $a=$row['Hrelease_status'];
                $b="<input type='radio' name='Hrelease_status' value='1' checked>發佈中
                <input type='radio' name='Hrelease_status' value='2'>發佈結束
                <input type='radio' name='Hrelease_status' value='3'>未發佈";
                $c="<input type='radio' name='Hrelease_status' value='1'>發佈中
                <input type='radio' name='Hrelease_status' value='2' checked>發佈結束
                <input type='radio' name='Hrelease_status' value='3'>未發佈";
                $d="<input type='radio' name='Hrelease_status' value='1'>發佈中
                <input type='radio' name='Hrelease_status' value='2'>發佈結束
                <input type='radio' name='Hrelease_status' value='3' checked>未發佈";
                if($a=="1"){echo $b;}
                if($a=="2"){echo $c;}
                if($a=="3"){echo $d;}
                ?>
                </td>
                <td>
                <input type="file" name="Hpicture">
                </td>
                <td>
                <input type="Text" name="Hpayment" value="<?php 
                echo $row["Hpayment"] ?>">
                </td>
            </tr>
            <?php 
            }
            ?>
            </table>   
    <br>
    <div class="align-r">
    <button type="submit">提交</button>
    <button type="button" onclick="window.location.href='health.php'">取消</button>
        </div>
        </form>
</div>
</body>
</html>