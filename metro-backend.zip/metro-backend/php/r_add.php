<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <?php include '../php/index.php';?>
</head>

<body>


<div id="page-wrapper">
    
        <h1 class="page-header">新增病人預約記錄</h1>
<form action="../php/reservedata_add.php" method="post">

    <label>姓名</label>
        <input type="text" name="Rname">
        <label>電話</label>
        <input type="text" name="Rphone">

        <div class="row">
        <div class="col-md-3">
        <label>預約日期</label>
        <input type="date" name="Rdate">
</div>

<div class="col-md-7">
        <label>預約時間</label>
        <input type="radio" name="Rtime" value="1">08:00-10:00
        <input type="radio" name="Rtime" value="2">10:00-12:00
        <input type="radio" name="Rtime" value="3">14:00-16:00
        <input type="radio" name="Rtime" value="4">16:00-18:00

</div>

</div>
        <label>預約地址</label>
        <input type="Text" name="Raddress" list="addresslist">
        <datalist id="addresslist">
        <option >荃灣都會醫務所</option>
        <option >金鐘都會醫務所</option>
        <option >旺角都會醫務所</option>
        </datalist>
        <input type="hidden" name="Rcondition" value="1" checked>

<br>
<div class="align-r">
<button class="clear-btn cancel" type="button" onclick="window.location.href='../php/reservedata.php'">取消</button>
    <button class="primary-btn" type="submit">提交</button>
</div>
</form>
</div>

</body>
</html>