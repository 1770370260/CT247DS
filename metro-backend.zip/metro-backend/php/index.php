<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Metro Medical 網站後台</title>


    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/main.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">


</head>

<body>
 <!-- <?php
 session_start();
        $conn = new mysqli('localhost', 'root', '','appDB');
        $UID = $_GET['UID'];
        
        $count = "select Rcondition from reserve_data where Rcondition = '1'";
        $count2 = "select Rcondition from reserve_data where Rcondition = '2'";
        $count3 = "select Rcondition from reserve_data where Rcondition = '3'";
        $count4 = "select Rcondition from reserve_data where Rcondition = '4'";
        $count5 = "select Rcondition from reserve_data where Rcondition = '5'";
        $res = $conn->query($count);$res2 = $conn->query($count2);
        $res3 = $conn->query($count3);$res4 = $conn->query($count4);
        $res5 = $conn->query($count5);
        $num = mysqli_num_rows($res);$num2 = mysqli_num_rows($res2);
        $num3 = mysqli_num_rows($res3);$num4 = mysqli_num_rows($res4);
        $num5 = mysqli_num_rows($res5);
        $sql = "select username from user_info where UID = '$UID'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $username = $row['username'];
        
    ?>  -->

<!-- Start navbar-top-links -->
<nav>
        <div class="navbar-header">
                <!-- <a class="navbar-brand" href="home.php?UID=$UID"></a> -->
    
                    <!-- <ul class="nav navbar-nav navbar-left navbar-top-links">
                        <li><a href="home.php?UID=$UID" style="padding:5px 0 0 0;"><img style="width:220px; " src="../assets/logo-h.png" alt="login"></a></li>
                    </ul> -->
    
                    <ul class="nav navbar-right navbar-top-links">
                        <li class="dropdown navbar-inverse">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-bell fa-fw warning"></i><?php echo "(" . " $num " . ")" ;
?><b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu dropdown-alerts">                        
                                <li>
                                    <a href="#">
                                        <div>
                                            <i class="fa fa-envelope fa-fw"></i> 新預約
                                            <span class="pull-right text-muted small"><?php echo " $num " . "項" ;
?> </span>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <li><a href="../php/logout.php"><i class="fa fa-sign-out fa-fw"></i> 登出</a>
                        <!-- <li class="dropdown">
                           <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-user fa-fw"></i> <?php echo $username ?><b class="caret"></b>
                           </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#"><i class="fa fa-user fa-fw"></i> 我的帳戶</a>
                                </li>
                                <li><a href="#"><i class="fa fa-gear fa-fw"></i> 設定</a>
                                </li>
                                <li class="divider"></li>
                                <li><a href="../php/logout.php"><i class="fa fa-sign-out fa-fw"></i> 登出</a>
                                </li> -->
                            </ul>     
                              
                        </li>
                    </ul></nav>
                    
            </div>
            <!-- End of navbar-top-links -->
            
<!-- Start sidebar-->
    <div class="navbar-default sidebar" role="navigation">
        <div class="sidebar-nav navbar-collapse">
            <ul class="nav" id="side-menu">

            
            <a href="home.php?UID=<?PHP echo $_SESSION['UID'] ?>" style="padding:5px 0 0 0;"><img style="width:230px;" src="../assets/logo-h.png" alt="login"></a>
            
                <li class="sidebar-search">
                    <div class="input-group custom-search-form">
                        <input type="text" class="form-control" placeholder="Search...">
                        <span class="input-group-btn">
                            <button class="btn clear-btn primary" type="button">
                                <i class="fa fa-search"></i>
                            </button>
                        </span>
                    </div>
                    <!-- /input-group -->
                </li>
                <li>
                <a href="home.php?UID=<?PHP echo $_SESSION['UID'] ?>"> 儀表版</a>
                </li>
                <li>
                    <a href="patientdata.php?UID=<?PHP echo $_SESSION['UID'] ?>" >病人資料庫</a>
                </li>
                <li>
                    <a href="reservedata.php?UID=<?PHP echo $_SESSION['UID'] ?>">病人掛號記錄資料庫</a>
                </li>
                <li>
                    <a href="clinic.php?UID=<?PHP echo $_SESSION['UID'] ?>">醫務所資料</a>
                </li>
                <li>
                    <a href="health.php?UID=<?PHP echo $_SESSION['UID'] ?>">醫療健康資訊</a>
      
                </li>
            </ul>
    
        </div>

    </div>

<!-- End of sidebar -->


   <!-- jQuery -->
   <script src="../js/jquery.min.js"></script>

   <!-- Bootstrap Core JavaScript -->
   <script src="../js/bootstrap.min.js"></script>

   <!-- Metis Menu Plugin JavaScript -->
   <!-- <script src="../js/metisMenu.min.js"></script> -->

   <!-- Morris Charts JavaScript -->
   <!-- <script src="../js/raphael.min.js"></script>
   <script src="../js/morris.min.js"></script>
   <script src="../js/morris-data.js"></script> -->

   <!-- Custom Theme JavaScript -->
   <!-- <script src="../js/startmin.js"></script> -->
</body>

</html>