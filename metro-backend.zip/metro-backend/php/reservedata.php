<!DOCTYPE html>
<html>
<head>
<?php include '../php/index.php';?>
</head>
<body>

<div id="page-wrapper">
<h1 class="page-header">病人預約記錄表</h1>
<div>
    過濾選項：
        <select id="Rslt" onchange="test()">
        <option value="">請選擇</option>
        <option value="1">新預約</option>
        <option value="2">已簽到</option>
        <option value="3">預約中</option>
        <option value="4">已完成預約</option>
        <option value="5">取消預約</option>
        <option value="">所有</option>
        </select>
        <script>
        document.cookie = "Rres_select"+" = "+""+";" ;
        function test(){
        var name = "Rres_select",value=document.getElementById("Rslt").value;
        document.cookie = name+" = "+value+";" ;
        window.location.reload();
        }
        </script>
        <button class="dark-btn align-r" onclick="location.href='../php/r_add.php?UID=<?PHP echo $_SESSION['UID'] ?>'" >新增資料</button>

    <div>
        <table>
            <tr class="secondary">
            <th>預約時間</th>
                <th>預約日期</th>
                <th>姓名</th>
                <th>電話</th>
                <th>預約地址</th>
                <th>處理狀態</th>
                <th></th>

            </tr>
            <?php
            $conn = new mysqli('localhost', 'root', '','appDB');
            mysqli_set_charset($conn,"utf8");

            $res_select=$_COOKIE["Rres_select"];
            switch ($res_select) {
                case "1":
                  $sql="select * from reserve_data where Rcondition = '1'";
                  break;
                case "2":
                  $sql="select * from reserve_data where Rcondition = '2'";
                    break;
                case "3":
                  $sql="select * from reserve_data where Rcondition = '3'";
                    break;
                case "4":
                  $sql="select * from reserve_data where Rcondition = '4'";
                    break;
                case "5":
                  $sql="select * from reserve_data where Rcondition = '5'";
                    break;
                default:
                $sql="select * from reserve_data";
            }
            while($row = $result->fetch_assoc()){
            ?>
            <tr>
                <td>
                    <?php
                    $a = $row['Rtime'];
                    if ($a == "1"){echo "08:00-10:00";}
                    if ($a == "2"){echo "10:00-12:00";}
                    if ($a == "3"){echo "14:00-16:00";}
                    if ($a == "4"){echo "16:00-18:00";}
                    ?>
                </td>
                <td>
                    <?php echo $row['Rdate'] ?>
                </td>
                <td>
                    <?php echo $row['Rname'] ?>
                </td>
                <td>
                    <?php echo $row['Rphone'] ?>
                </td>
                <td>
                    <?php echo $row['Raddress'] ?>
                </td>
                <td>
                    <?php
                    $b = $row['Rcondition'];
                    if ($b == "1"){echo "新預約";}
                    if ($b == "2"){echo "已簽到";}
                    if ($b == "3"){echo "預約中";}
                    if ($b == "4"){echo "已完成預約";}
                    if ($b == "5"){echo "取消預約";}
                    ?>
                </td>
                <td>
                <input class="clear-btn danger" type="button" onclick="window.location.href='reservedata_delete.php?RID=<?PHP echo $row['RID']; ?>'" value="删除"/>
                <input class="clear-btn secondary" type="button" onclick="window.location.href='r_update.php?RID=<?PHP echo $row['RID']; ?>'" value="编輯"/>
                </td>
            </tr>
            <?php 
            }
            ?>
            </table>   
    </div>    </div>
</div>
</div>
</body>
</html>