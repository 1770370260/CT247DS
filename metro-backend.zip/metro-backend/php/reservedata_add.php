<?php
    header("Content-type: text/html; charset=utf-8");
    $time = $_POST['Rtime'];
    $date = $_POST['Rdate'];
    $Rname = $_POST['Rname'];
    $Raddress = $_POST['Raddress'];
    $Rphone = $_POST['Rphone'];
    $Rcondition = $_POST['Rcondition'];
    $conn = new mysqli('localhost', 'root', '','appDB');
    mysqli_set_charset($conn,"utf8");


        if ($conn->connect_error){
            echo '數據庫連接失敗！';
            exit(0);
        }else{
            if ($time == ''){
                echo '<script>alert("預約時間不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($date == ''){
                echo '<script>alert("預約日期不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($Rname == ''){
                echo '<script>alert("姓名不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($Rphone == ''){
                echo '<script>alert("電話不能為空！");history.go(-1);</script>';
                exit(0);}
            if ($Raddress == ''){
                echo '<script>alert("預約地址不能為空！");history.go(-1);</script>';
                exit(0);}
        
                $sql = "select Rname and Rphone from reserve_data where Rname = '$_POST[Rname]' and Rphone = '$_POST[Rphone]'";
                $result = $conn->query($sql);
                $number = mysqli_num_rows($result);
                if ($number) {
                    echo '<script>alert("信息不可重複");history.go(-1);</script>';
                } else {
                    $sql_insert = "insert into reserve_data 
                    values('','$_POST[Rtime]','$_POST[Rdate]','$_POST[Rname]','$_POST[Rphone]','$_POST[Raddress]','$_POST[Rcondition]','')";
                    $res_insert = $conn->query($sql_insert);
        if ($res_insert) {
            echo "<script>alert('新增成功！')</script>";echo '<script>window.location.href="reservedata.php";</script>';
        }else {
            echo "<script>alert('新增失敗！'); history.go(-1);</script>";
        }}}
?>