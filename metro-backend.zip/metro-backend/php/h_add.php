<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <?php include '../php/index.php';?>
</head>

<body>


<div id="page-wrapper">
    
        <h1 class="page-header">新增醫療健康資訊</h1>
        <form action="health_add.php" method="post" enctype="multipart/form-data">
    <div>
        <label>標題</label>
        <input type="text" name="Htitle">

        <div class="row">
            <div class="col-md-3">
        <label>發佈日期</label>
        <input type="date" name="Hcreate_datetime">
</div>
        <div class="col-md-5">
        <label>發佈狀態</label>
        <input type="radio" name="Hrelease_status" value="1">發佈中
        <input type="radio" name="Hrelease_status" value="2">發佈結束
        <input type="radio" name="Hrelease_status" value="3">未發佈
</div>
</div>
        <label>圖片</label>
        <input type="file" name="Hpicture">
        <label>收費</label>
        <input type="number" name="Hpayment">
        <label>簡介</label>
        <input type="textarea" name="Hintro">
    </div>
    <br>

    <div class="align-r">
    <button class="clear-btn cancel" type="button" onclick="window.location.href='health.php?UID=<?PHP echo $_SESSION['UID'] ?>' ">取消</button>
    <button class="primary-btn" type="submit">提交</button>
</div>
</form>
</div>

</body>
</html>