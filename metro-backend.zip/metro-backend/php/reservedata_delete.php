<?php
header("Content-type: text/html; charset=utf-8");
    $RID = $_GET['RID'];

    $conn = new mysqli('localhost','root','','appDB');
    mysqli_set_charset($conn,"utf8");

        if ($conn->connect_error){
            echo '數據庫連接失敗！';exit(0);
        }else {
            $sql_delete = "delete from reserve_data where RID = '$RID'";
            $res_delete = $conn->query($sql_delete);
        if ($res_delete) {
            echo "<script>alert('刪除成功！')</script>";echo '<script>window.location.href="reservedata.php";</script>';
        }else {
            echo "<script>alert('刪除失敗！'); history.go(-1);</script>";
        }}
?>