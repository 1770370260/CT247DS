<!DOCTYPE html>
<html>
<head>
<?php include '../php/index.php';?>
</head>
<body>

<div id="page-wrapper">
<div class="row">
<h1 class="page-header">醫務所資料</h1>
<div>
過濾選項：
        <select id="Cslt" onchange="test()">
        <option value="">請選擇</option>
        <option value="1">發佈中</option>
        <option value="2">發佈結束</option>
        <option value="3">未發佈</option>
        <option value="">所有</option>
        </select>
        <script>
        document.cookie = "Cres_select"+" = "+""+";" ;
        function test(){
        var name = "Cres_select",value=document.getElementById("Cslt").value;
        document.cookie = name+" = "+value+";" ;
        window.location.reload();
        }
        </script>
<button class="dark-btn align-r" onclick="location.href='c_add.php?UID=$UID'">新增資料</button>
</div>
</div>
     
    <div>
        <table>
            <tr class="secondary">
            <th>醫務所名稱</th>
                <th>醫生</th>
                <th>主理醫療項目</th>
                <th>醫務所地址</th>
                <th>圖片</th>
                <th>電話</th>
                <th>發佈狀態</th>
                <th>收費</th>
                <th></th>
            </tr>
            <?php
            $conn = new mysqli('localhost', 'root', '','appDB');
            mysqli_set_charset($conn,"utf8");

            $res_select=$_COOKIE["Cres_select"];
            switch ($res_select) {
                case "1":
                $sql="select * from clinic_info where Crelease_status = '1'";
                  break;
                case "2":
                $sql="select * from clinic_info where Crelease_status = '2'";
                  break;
                case "3":
                $sql="select * from clinic_info where Crelease_status = '3'";
                  break;
                default:
                $sql="select * from clinic_info";
            }
            $result=$conn->query($sql);
            while($row = $result->fetch_assoc()){
            ?>
            <tr>
                <td>
                    <?php echo $row['Cname'] ?>
                </td>
                <td>
                    <?php echo $row['Cdoctor_name'] ?>
                </td>
                <td>
                    <?php echo $row['Cpractice_type'] ?>
                </td>
                <td class="td-l">
                    <?php echo $row['Caddress'] ?>
                </td>
                <td>
                <?PHP echo '<img src="data:'.$row["CPtype"].";base64,". 
                    base64_encode($row["Cpicture"]).'">'; ?>
                </td>
                <td>
                    <?php echo $row['Cphone'] ?>
                </td>
                <td>
                    <?php 
                    $a = $row['Crelease_status'];
                    if ($a == "1"){echo "發佈中";}
                    if ($a == "2"){echo "發佈結束";}
                    if ($a == "3"){echo "未發佈";}
                    ?>
                </td>
                <td>
                    <?php echo $row['Cpayment'] ?>
                </td>
                
                <td class="td-s">
                <input class="clear-btn danger" type="button" onclick="window.location.href='clinic_delete.php?CID=<?PHP echo $row['CID']; ?>'" value="删除"/>
                <input class="clear-btn secondary" type="button" onclick="window.location.href='c_update.php?CID=<?PHP echo $row['CID']; ?>'" value="编輯"/>
                </td>
            </tr>
            <?php 
            }
            ?>
            </table>   
    </div>
</div>    </div>
</body>
</html>