<?php
    header("Content-type: text/html; charset=utf-8");
        $Cname = $_POST['Cname'];
        $doctor_name = $_POST['Cdoctor_name'];
        $practice_type = $_POST['Cpractice_type'];
        $Caddress = $_POST['Caddress'];
        $size = $_FILES['Cpicture']['size'];
        $name = $_FILES['Cpicture']['name'];
        $tmp_name = $_FILES['Cpicture']['tmp_name'];
        $type = $_FILES['Cpicture']['type'];
        $Chone = $_POST['Chone'];
        $Cpayment = $_POST['Cpayment'];
        $release_status = $_POST['Crelease_status'];
        $CID = $_GET['CID'];
        $data = addslashes(fread(fopen($tmp_name, "r"), filesize($tmp_name)));
        $conn = new mysqli('localhost', 'root', '','appDB');
        mysqli_set_charset($conn,"utf8");

        if ($conn->connect_error){
            echo '數據庫連接失敗！';
            exit(0);
        }else{
        if ($Cname == ''){
            echo '<script>alert("診所名不能為空！");history.go(-1);</script>';
            exit(0);}
        if ($Caddress == ''){
            echo '<script>alert("醫務所地址不能為空！");history.go(-1);</script>';
            exit(0);}
        if ($doctor_name == ''){
            echo '<script>alert("醫生名不能為空！");history.go(-1);</script>';
            exit(0);}
        if ($practice_type == ''){
            echo '<script>alert("主理醫療項目不能為空！");history.go(-1);</script>';
            exit(0);}
        if ($release_status == ''){
            echo '<script>alert("發佈狀態不能為空！");history.go(-1);</script>';
            exit(0);}
        if ($Cpayment == ''){
            echo '<script>alert("收費不能為空！");history.go(-1);</script>';
            exit(0);}
        
        $sql = "select Cname and Cdoctor_name from clinic_info where Cname = '$_POST[Cname]' and Cdoctor_name = '$_POST[Cdoctor_name]' ";
        $result = $conn->query($sql);
        $number = mysqli_num_rows($result);
        if ($number) {
            echo '<script>alert("信息不可重複");history.go(-1);</script>';
        } else {
            $sql_insert = "insert into clinic_info 
            values('','$_POST[Cname]','$_POST[Cdoctor_name]','$_POST[Cpractice_type]','$_POST[Caddress]','$data','$type','$_POST[Cphone]','$_POST[Crelease_status]','$_POST[Cpayment]')";
            $res_insert = $conn->query($sql_insert);
        if ($res_insert) {
            echo "<script>alert('新增成功！')</script>";echo '<script>window.location.href="clinic.php";</script>';
        }else {
            echo "<script>alert('新增失敗！'); history.go(-1);</script>";
        }}}
?>