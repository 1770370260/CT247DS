<?php
header("Content-type:text/html;charset=utf-8");  

header('Access-Control-Allow-Origin: *');

header("Access-Control-Allow-Credentials: true");

header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');

header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
$dbhost = "localhost";
$username = "root";
$password = "";
$dbname = "appdb";
$dbport = "3306";
$charset = "utf8";

$dsn = "mysql:host={$dbhost};port={$dbport};dbname={$dbname};charset={$charset}";
try{
    $mjson = file_get_contents("php://input");
    $result = json_decode($mjson);
    $conn = new PDO($dsn, $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $conn->prepare("INSERT INTO user_info (name_EN,email,ident_no,ident_type,phone,address,username,password,repassword,user_type,receive_news,Privacy_policy)
    VALUES (:name_EN, :email, :ident_no, :ident_type, :phone, :address, :username, :password, :repassword, :user_type, :receive_news, :Privacy_policy)");
    $stmt->bindParam(':name_EN', $name_EN);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':ident_no', $ident_no);
    $stmt->bindParam(':ident_type', $ident_type);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':repassword', $repassword);
    $stmt->bindParam(':user_type',$user_type);
    $stmt->bindParam(':receive_news',$receive_news);
    $stmt->bindParam(':Privacy_policy',$Privacy_policy);

    $name_EN= $result->name_EN;
    $email= $result->email ;
    $ident_no= $result->ident_no;
    $ident_type= $result->ident_type;
    $phone= $result->phone;
    $address= $result->address;
    $username= $result->username ;
    $password= md5($result->password);
    $repassword= md5($result->repassword); 
    $user_type= $result->user_type;
    $receive_news= $result->receive_news;
    $Privacy_policy= $result->Privacy_policy;

    $stmt2= $conn->prepare("SELECT UID FROM user_info WHERE username =:username LIMIT 1"); //SELECT主鍵
    $stmt2->bindParam(":username", $username);
    $stmt2->execute();

    if ($password != $repassword){
        echo $JSON_RESULT = '[{"result": "密碼不相符"}]';
    }else if ($stmt2 -> rowCount()>0){
        echo $JSON_RESULT = '[{"result": "帳戶已存在"}]';
    }else{
        $stmt->execute();
        if($stmt->rowCount() >0){
            echo $JSON_RESULT = '[{"result": "成功"}]';
        }
    }
    die();
}catch(PODException $e){
    $JSON_RESULT = '[{"result": "'. $e->getmessage(). '"}]';
    echo json_encode( $JSON_RESULT, JSON_UNESCAPED_UNICODE);
}
$conn = nnull;
?>