<?php

header("Access-Control-Allow-Origin: *");      
$dbhost = "localhost";
$username = "root";
$password = "";
$dbname = "appdb";
$dbport = "3306";
$charset = "utf8";

$dsn = "mysql:host={$dbhost};port={$dbport};dbname={$dbname};charset={$charset}";




// push message, change message here ------
$msg = array
(
    'body'  => 'Here is a new message.',
    'title'     => 'This is a health title.',
    'subtitle'  => 'New message is received.'
);





$to;


try {


        ///$mjson = file_get_contents("php://input"); 
        ///$result = json_decode($mjson); 
		    //$RID = $result -> RID; 
            // $RID =$_GET["RID"]; 


            $conn = new PDO($dsn, $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
            $stmt = $conn->prepare("Select * from user_info");
            		
        	$stmt->execute();
			$stmt->setFetchMode(PDO::FETCH_ASSOC); 
            foreach($stmt->fetchAll() as $row){				
                  $to = $row["token"];
               echo "" .$row["token"]. " ";
		       sendPushNotification ($to, $msg);
            }
			
           die();
} catch(PDOException $e){
   echo "Error result";
}    
            
$conn = null;






function sendPushNotification ($token_to, $token_msg) {
	$fields = array( 'to' => $token_to, 'notification' => $token_msg );
	// FCM link
	$URL = 'https://fcm.googleapis.com/fcm/send';

//AAAASQq19Dw:APA91bH_2cqCAGgCF6aZePehlY3tkXW20WjCPf0VREz9Kyjh5Q-kXSRVrFG2m34auqD-_27cf2wNSjnhW3EVrBG7E_DC-uCwWQNUW2nX8u32vVDxCoYd1Zk0kIOOSOcXtLD0kke13d9q
//AIzaSyBLMIhI9XRMBbc6NWnwDS-lwibX484Z194
	 // API access key from Google API's Console
    $api_key = 'AIzaSyBLMIhI9XRMBbc6NWnwDS-lwibX484Z194';
	$headers = array('Authorization: key=' .$api_key, 'Content-Type: application/json');
	
		
	
    $ch = curl_init();
    
	curl_setopt( $ch,CURLOPT_URL, $URL);
    curl_setopt( $ch,CURLOPT_POST, true );
    curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
    curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
    curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
    curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
    $result = curl_exec($ch );
    curl_close( $ch );
    echo $result;
	
}




	   
?>
             

               
            